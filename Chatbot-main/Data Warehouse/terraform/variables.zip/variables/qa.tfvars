# common
environment         = "qa"
location = "Canada Central"
data_location = "United States"

# communication_email_service
communication_email_name = "sgc-dataWarehouse-email-comm-qa"

# communication_service
communication_name = "sgc-dataWarehouse-communication-qa"

# function app
app_name   = "sgc-dataWarehouse-function-qa"

# key vault
keyvault_name      = "sgc-dw-kv-qa"
keyvault_sku_name  = "standard"
tenant_id = "04c70eb4-8f26-4807-9934-e02e89266ad0"

# postgres server
postgres_dbserver_name = "sgc-datawarehouse-psqlflexibleserver-qa"
postgres_version          = "12"
postgres_admin_user       = "psqladmin"
postgres_admin_password   = "careercenterQA!yeshiva01"
postgres_sku_name         = "GP_Standard_D4s_v3"
postgres_storage_mb       = 32768

# postgres server db
pg_flexible_server_db = "sgc-fv-psqlflexibleserver-qa"

# private_dns_zone
private_dns_zone_name = "sgc-datawarehouse-privatednszone-qa.postgres.database.azure.com"
 
# private_dns_zone_vnet
private_dns_zone_vnet_link_name = "sgc-datawarehouse-pdns-qa"

# resource_group
resource_group_name = "sgc-dataWarehouse-rg-qa"

# service_plan
service_plan_name = "sgc-dataWarehouse-serviceplan-qa"

# storage account
storage_account_name = "sgcdatawarehousesaqa"
account_tier = "Standard"
account_replication_type = "LRS"

# subnet
subnet_name = "sgc-dataWarehouse-subnet-qa"
subnet_address_prefixes =  ["10.0.1.0/24"]
subnet_delegation_name = "sgc-dataWarehouse-subnetDelegation-qa"

# vnet
vnet_name = "sgc-dataWarehouse-vnet-qa"
vnet_address_space = ["10.0.0.0/16"]