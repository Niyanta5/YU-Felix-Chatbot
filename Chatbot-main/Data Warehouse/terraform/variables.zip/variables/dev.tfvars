# common
environment         = "dev"
location = "Canada Central"
data_location = "United States"

# communication_email_service
communication_email_name = "sgc-dataWarehouse-email-comm-dev"

# communication_service
communication_name = "sgc-dataWarehouse-communication-dev"

# function app
app_name   = "sgc-dataWarehouse-function-dev"

# key vault
keyvault_name      = "sgc-dw-kv-dev"
keyvault_sku_name  = "standard"
tenant_id = "04c70eb4-8f26-4807-9934-e02e89266ad0"

# postgres server 
#db = sgc_db
postgres_dbserver_name = "pgserver-sgc-warehouse.postgres.database.azure.com"
postgres_version          = "12"
postgres_admin_user       = "susan"
postgres_admin_password   = "@Yeshivasgc"
postgres_sku_name         = "GP_Standard_D4s_v3"
postgres_storage_mb       = 32768

# postgres server db
pg_flexible_server_db = "sgc-fv-psqlflexibleserver-dev"

# private_dns_zone
private_dns_zone_name = "sgc-datawarehouse-privatednszone-dev.postgres.database.azure.com"
 
# private_dns_zone_vnet
private_dns_zone_vnet_link_name = "sgc-datawarehouse-pdns-dev"

# resource_group
resource_group_name = "sgc-dataWarehouse-rg-dev"

# service_plan
service_plan_name = "sgc-dataWarehouse-serviceplan-dev"

# storage account
storage_account_name = "sgcdatawarehousesadev"
account_tier = "Standard"
account_replication_type = "LRS"

# subnet
subnet_name = "sgc-dataWarehouse-subnet-dev"
subnet_address_prefixes =  ["10.0.1.0/24"]
subnet_delegation_name = "sgc-dataWarehouse-subnetDelegation-dev"

# vnet
vnet_name = "sgc-dataWarehouse-vnet-dev"
vnet_address_space = ["10.0.0.0/16"]